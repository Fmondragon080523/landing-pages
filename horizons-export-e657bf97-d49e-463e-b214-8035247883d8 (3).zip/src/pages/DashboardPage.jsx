
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import Navbar from '@/components/Navbar';
import { useAuth } from '@/contexts/AuthContext';
import DashboardHeader from '@/components/dashboard/DashboardHeader';
import AnalyticsTab from '@/components/dashboard/AnalyticsTab';
import LandingPagesTab from '@/components/dashboard/LandingPagesTab';
import UserManagementTab from '@/components/dashboard/UserManagementTab';
import IntegrationSettingsTab from '@/components/dashboard/IntegrationSettingsTab';
import { useLandingPages } from '@/hooks/useLandingPages';
import { useUsers } from '@/hooks/useUsers';
import { useIntegrationSettings } from '@/hooks/useIntegrationSettings';

function DashboardPage() {
  const navigate = useNavigate();
  const { user, isAdmin } = useAuth();

  const { landingPages, updateLandingPages } = useLandingPages(user, isAdmin);
  const { allUsers, updateAllUsers } = useUsers(isAdmin);
  const { integrationSettings, updateIntegrationSettings } = useIntegrationSettings(user, isAdmin);

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <div className="container mx-auto px-4 py-8">
        <DashboardHeader user={user} isAdmin={isAdmin} onCreatePage={() => navigate('/generator')} />

        <Tabs defaultValue="analytics" className="space-y-8">
          <TabsList className="grid w-full grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
            <TabsTrigger value="analytics">Análisis</TabsTrigger>
            <TabsTrigger value="pages">Landing Pages</TabsTrigger>
            <TabsTrigger value="integrations">Integraciones</TabsTrigger>
            {isAdmin && <TabsTrigger value="users">Gestión de Usuarios</TabsTrigger>}
          </TabsList>

          <TabsContent value="analytics">
            <AnalyticsTab landingPages={landingPages} />
          </TabsContent>

          <TabsContent value="pages">
            <LandingPagesTab 
              landingPages={landingPages} 
              onUpdatePages={updateLandingPages} 
              navigate={navigate} 
            />
          </TabsContent>
          
          <TabsContent value="integrations">
              <IntegrationSettingsTab 
                settings={integrationSettings}
                onUpdateSettings={updateIntegrationSettings}
                isAdmin={isAdmin}
              />
            </TabsContent>

          {isAdmin && (
            <TabsContent value="users">
              <UserManagementTab 
                allUsers={allUsers} 
                onUpdateUsers={updateAllUsers} 
                currentUserEmail={user?.email}
              />
            </TabsContent>
          )}
        </Tabs>
      </div>
    </div>
  );
}

export default DashboardPage;
