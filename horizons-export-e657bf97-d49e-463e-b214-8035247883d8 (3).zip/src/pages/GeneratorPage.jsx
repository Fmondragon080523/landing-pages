
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useNavigate, useParams } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ChromePicker } from 'react-color';
import Navbar from '@/components/Navbar';
import { useToast } from '@/components/ui/use-toast';
import { UploadCloud, Palette, Type, Image as ImageIcon, Trash2, Settings, Mail, Facebook, PlusCircle } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';

const predefinedTemplates = [
  {
    id: 'template1',
    name: 'Consultoría Moderna',
    defaultData: {
      title: 'Consultoría Estratégica Digital',
      description: 'Impulsa tu negocio al siguiente nivel con nuestras soluciones innovadoras.',
      primaryColor: '#5E4AE3', 
      secondaryColor: '#F970B5', 
      font: 'Poppins',
      heroImage: '', 
      sections: [{ type: 'hero', title: 'Título Hero', content: 'Contenido Hero' }, { type: 'faq', title: 'Preguntas Frecuentes', items: [{q: 'Pregunta 1?', a: 'Respuesta 1'}, {q: 'Pregunta 2?', a: 'Respuesta 2'}] }],
    }
  },
  {
    id: 'template2',
    name: 'Servicio Tecnológico',
    defaultData: {
      title: 'Soluciones Tech Avanzadas',
      description: 'Tecnología de vanguardia para optimizar tus procesos.',
      primaryColor: '#10B981', 
      secondaryColor: '#3B82F6', 
      font: 'Inter',
      heroImage: '',
      sections: [{ type: 'hero', title: 'Título Hero Tech', content: 'Contenido Hero Tech' }, { type: 'features', title: 'Características Destacadas', items: [{name: 'Feature 1', desc: 'Descripción 1'}, {name: 'Feature 2', desc: 'Descripción 2'}] }],
    }
  },
];

const availableFonts = ['Poppins', 'Inter', 'Roboto', 'Montserrat', 'Lato'];

function GeneratorPage() {
  const navigate = useNavigate();
  const { id: pageId } = useParams(); 
  const { toast } = useToast();
  const { user, isAdmin } = useAuth();
  const [isEditing, setIsEditing] = useState(false);

  const getInitialLandingPageData = () => {
    const userSettingsKey = user ? `userIntegrationSettings_${user.id}` : null;
    const userSettings = userSettingsKey ? JSON.parse(localStorage.getItem(userSettingsKey) || '{}') : {};
    const globalSettings = isAdmin ? JSON.parse(localStorage.getItem('globalIntegrationSettings') || '{}') : {};
    
    return {
        id: null,
        userId: user?.id,
        title: '',
        description: '',
        primaryColor: '#5E4AE3',
        secondaryColor: '#F970B5',
        font: 'Poppins',
        heroImage: '',
        whatsappNumber: '',
        calendarUrl: '',
        questions: [{ id: Date.now(), question: '¿Estás interesado en nuestro servicio?', type: 'yes_no', options: [] }],
        sections: [{ id: Date.now(), type: 'hero', title: 'Bienvenido', content: 'Descripción inicial' }],
        templateId: null,
        facebookPixelId: userSettings.facebookPixelId || globalSettings.facebookPixelId || '',
        mailchimpFormAction: userSettings.mailchimpFormAction || '', // Mailchimp settings usually per-user or per-page
        mailchimpEmailFieldName: userSettings.mailchimpEmailFieldName || 'EMAIL',
    };
  };
  
  const [landingPage, setLandingPage] = useState(getInitialLandingPageData());

  useEffect(() => {
    if (pageId) {
      const pages = JSON.parse(localStorage.getItem('landingPages') || '[]');
      const pageToEdit = pages.find(p => p.id === parseInt(pageId));
      if (pageToEdit && (isAdmin || pageToEdit.userId === user?.id)) {
        setLandingPage(prev => ({ ...getInitialLandingPageData(), ...pageToEdit }));
        setIsEditing(true);
      } else {
        toast({ title: "Error", description: "Landing page no encontrada o no tienes permiso para editarla.", variant: "destructive" });
        navigate('/dashboard');
      }
    } else {
      setLandingPage(getInitialLandingPageData()); // Ensure fresh state with user/global settings for new page
      setIsEditing(false);
    }
  }, [pageId, navigate, toast, user, isAdmin]);

  const handleTemplateSelect = (templateId) => {
    const selectedTemplate = predefinedTemplates.find(t => t.id === templateId);
    if (selectedTemplate) {
      const baseData = getInitialLandingPageData();
      setLandingPage({
        ...baseData,
        ...selectedTemplate.defaultData,
        sections: selectedTemplate.defaultData.sections.map(s => ({...s, id: Date.now() + Math.random()})), // Unique IDs for sections
        questions: (selectedTemplate.defaultData.questions || baseData.questions).map(q => ({...q, id: Date.now() + Math.random()})), // And questions
        id: landingPage.id, // Preserve existing ID if editing
        userId: user?.id,
        templateId: templateId,
        facebookPixelId: landingPage.facebookPixelId || baseData.facebookPixelId, // Keep user/global if already set
        mailchimpFormAction: landingPage.mailchimpFormAction || baseData.mailchimpFormAction,
        mailchimpEmailFieldName: landingPage.mailchimpEmailFieldName || baseData.mailchimpEmailFieldName,
      });
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setLandingPage(prev => ({ ...prev, [name]: value }));
  };

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setLandingPage({ ...landingPage, heroImage: reader.result });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleQuestionChange = (index, field, value) => {
    const newQuestions = [...landingPage.questions];
    newQuestions[index][field] = value;
    setLandingPage({ ...landingPage, questions: newQuestions });
  };

  const addQuestion = () => {
    setLandingPage(prev => ({
      ...prev,
      questions: [...prev.questions, { id: Date.now(), question: '', type: 'yes_no', options: [] }]
    }));
  };

  const removeQuestion = (id) => {
    setLandingPage(prev => ({
      ...prev,
      questions: prev.questions.filter(q => q.id !== id)
    }));
  };
  
  const handleSave = () => {
    if (!landingPage.title || !landingPage.description) {
      toast({
        title: "Error",
        description: "Por favor completa al menos el título y la descripción.",
        variant: "destructive"
      });
      return;
    }

    try {
      let pages = JSON.parse(localStorage.getItem('landingPages') || '[]');
      const pageToSave = { ...landingPage, userId: user?.id };
      
      if (!pageToSave.id && !isEditing) {
        pageToSave.id = Date.now();
      }

      if (isEditing) {
        pages = pages.map(p => p.id === pageToSave.id ? pageToSave : p);
      } else {
        pages.push(pageToSave);
      }
      localStorage.setItem('landingPages', JSON.stringify(pages));

      toast({
        title: `¡Landing page ${isEditing ? 'actualizada' : 'creada'}!`,
        description: `Tu landing page ha sido ${isEditing ? 'actualizada' : 'guardada'} exitosamente.`,
      });
      navigate(`/preview/${pageToSave.id}`);
    } catch (error) {
      toast({
        title: "Error",
        description: `Hubo un error al ${isEditing ? 'actualizar' : 'guardar'} la landing page. ${error?.message || ''}`,
        variant: "destructive"
      });
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <Navbar />
      
      <div className="container mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-5xl mx-auto bg-white p-8 rounded-2xl shadow-xl"
        >
          <h1 className="text-4xl font-bold mb-2 gradient-text">{isEditing ? 'Editar' : 'Crear Nueva'} Landing Page</h1>
          <p className="text-slate-600 mb-8">Personaliza cada detalle para una landing page impactante.</p>

          {!isEditing && (
             <div className="mb-8 p-6 border border-dashed border-primary/50 rounded-lg bg-primary/5">
              <Label className="text-lg font-semibold text-primary mb-3 block">Elige una Plantilla (Opcional)</Label>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {predefinedTemplates.map(template => (
                  <Button
                    key={template.id}
                    variant={landingPage.templateId === template.id ? "default" : "outline"}
                    className="justify-start h-auto py-3 px-4 text-left"
                    onClick={() => handleTemplateSelect(template.id)}
                  >
                    <div>
                      <h3 className="font-semibold">{template.name}</h3>
                      <p className="text-xs opacity-75">{template.defaultData.title}</p>
                    </div>
                  </Button>
                ))}
              </div>
            </div>
          )}

          <Tabs defaultValue="basic" className="w-full">
            <TabsList className="grid w-full grid-cols-3 md:grid-cols-6 mb-8 bg-slate-100 p-1 rounded-lg">
              <TabsTrigger value="basic" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">Básico</TabsTrigger>
              <TabsTrigger value="design" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">Diseño</TabsTrigger>
              <TabsTrigger value="content" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">Contenido</TabsTrigger>
              <TabsTrigger value="form" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">Formulario</TabsTrigger>
              <TabsTrigger value="integration" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">Comunicaciones</TabsTrigger>
              <TabsTrigger value="tracking" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">Seguimiento</TabsTrigger>
            </TabsList>

            <TabsContent value="basic" className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="title" className="font-semibold">Título de la Landing Page</Label>
                  <Input id="title" name="title" placeholder="Ej: Consultoría de Marketing Digital" value={landingPage.title} onChange={handleInputChange} className="text-base"/>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="description" className="font-semibold">Descripción Corta</Label>
                  <Input id="description" name="description" placeholder="Describe tu servicio o producto en una frase" value={landingPage.description} onChange={handleInputChange} className="text-base"/>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="design" className="space-y-8">
              <div className="grid md:grid-cols-2 gap-8 items-start">
                <div>
                  <Label className="font-semibold text-lg mb-3 block flex items-center"><Palette size={20} className="mr-2 text-primary"/>Colores</Label>
                  <div className="space-y-4">
                    <div>
                      <Label>Color Primario</Label>
                      <ChromePicker color={landingPage.primaryColor} onChange={(color) => setLandingPage({ ...landingPage, primaryColor: color.hex })} disableAlpha className="mt-1 w-full max-w-xs"/>
                    </div>
                    <div>
                      <Label>Color Secundario</Label>
                      <ChromePicker color={landingPage.secondaryColor} onChange={(color) => setLandingPage({ ...landingPage, secondaryColor: color.hex })} disableAlpha className="mt-1 w-full max-w-xs"/>
                    </div>
                  </div>
                </div>
                <div className="space-y-6">
                    <div>
                        <Label className="font-semibold text-lg mb-3 block flex items-center"><Type size={20} className="mr-2 text-primary"/>Tipografía</Label>
                        <Select value={landingPage.font} onValueChange={(value) => setLandingPage({ ...landingPage, font: value })}>
                            <SelectTrigger className="w-full text-base">
                                <SelectValue placeholder="Selecciona una fuente" />
                            </SelectTrigger>
                            <SelectContent>
                                {availableFonts.map(fontName => (
                                <SelectItem key={fontName} value={fontName}>{fontName}</SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>
                    <div>
                        <Label className="font-semibold text-lg mb-3 block flex items-center"><ImageIcon size={20} className="mr-2 text-primary"/>Imagen Principal (Hero)</Label>
                        <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-dashed rounded-md">
                            <div className="space-y-1 text-center">
                                {landingPage.heroImage ? (
                                    <img src={landingPage.heroImage} alt="Hero Preview" className="mx-auto h-32 w-auto object-cover rounded-md mb-4" />
                                ) : (
                                     <img  alt="Subir archivo placeholder" class="mx-auto h-12 w-12 text-slate-400" src="https://images.unsplash.com/photo-1667984390553-7f439e6ae401" />
                                )}
                                <div className="flex text-sm text-slate-600">
                                    <label htmlFor="heroImage" className="relative cursor-pointer bg-white rounded-md font-medium text-primary hover:text-primary/80 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-primary">
                                        <span>Sube un archivo</span>
                                        <input id="heroImage" name="heroImage" type="file" className="sr-only" onChange={handleImageUpload} accept="image/*"/>
                                    </label>
                                    <p className="pl-1">o arrastra y suelta</p>
                                </div>
                                <p className="text-xs text-slate-500">PNG, JPG, GIF hasta 10MB</p>
                            </div>
                        </div>
                        {landingPage.heroImage && (
                            <Button variant="link" size="sm" className="mt-2 text-red-500" onClick={() => setLandingPage({...landingPage, heroImage: ''})}>Eliminar imagen</Button>
                        )}
                    </div>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="content" className="space-y-6">
              <Label className="font-semibold text-lg">Secciones de la Página (Próximamente editor avanzado)</Label>
                {landingPage.sections.map((section, index) => (
                    <div key={section.id || index} className="p-4 border rounded-md bg-slate-50 space-y-3">
                        <Input value={section.type} readOnly className="bg-slate-200 font-medium" />
                        <Input placeholder="Título de la sección" value={section.title} onChange={(e) => {
                            const newSections = [...landingPage.sections];
                            newSections[index].title = e.target.value;
                            setLandingPage({...landingPage, sections: newSections});
                        }} />
                        <Input placeholder="Contenido/Descripción de la sección" value={section.content} onChange={(e) => {
                            const newSections = [...landingPage.sections];
                            newSections[index].content = e.target.value;
                            setLandingPage({...landingPage, sections: newSections});
                        }} />
                    </div>
                ))}
            </TabsContent>


            <TabsContent value="form" className="space-y-6">
              <div className="space-y-4">
                <Label className="font-semibold text-lg">Preguntas de Calificación</Label>
                {landingPage.questions.map((q, index) => (
                  <div key={q.id || index} className="p-4 border rounded-md bg-slate-100 space-y-3">
                    <div className="flex gap-2 items-center">
                      <Input
                        placeholder="Escribe tu pregunta"
                        value={q.question}
                        onChange={(e) => handleQuestionChange(index, 'question', e.target.value)}
                        className="flex-grow"
                      />
                      <Select value={q.type} onValueChange={(value) => handleQuestionChange(index, 'type', value)}>
                        <SelectTrigger className="w-[180px]">
                          <SelectValue placeholder="Tipo de pregunta" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="yes_no">Sí / No</SelectItem>
                          <SelectItem value="text_input">Respuesta de Texto</SelectItem>
                          <SelectItem value="multiple_choice">Opción Múltiple</SelectItem>
                        </SelectContent>
                      </Select>
                      <Button variant="ghost" size="icon" onClick={() => removeQuestion(q.id)} className="text-red-500 hover:bg-red-100">
                        <Trash2 size={18}/>
                      </Button>
                    </div>
                    {q.type === 'multiple_choice' && (
                      <div className="pl-2 space-y-2">
                        {q.options.map((opt, optIndex) => (
                          <div key={optIndex} className="flex gap-2 items-center">
                            <Input 
                              placeholder={`Opción ${optIndex + 1}`}
                              value={opt}
                              onChange={(e) => {
                                const newOptions = [...q.options];
                                newOptions[optIndex] = e.target.value;
                                handleQuestionChange(index, 'options', newOptions);
                              }}
                            />
                            <Button variant="ghost" size="icon" onClick={() => {
                              const newOptions = q.options.filter((_, i) => i !== optIndex);
                              handleQuestionChange(index, 'options', newOptions);
                            }} className="text-red-400 hover:bg-red-50">
                              <Trash2 size={16} />
                            </Button>
                          </div>
                        ))}
                        <Button variant="outline" size="sm" onClick={() => {
                           const newOptions = [...q.options, ''];
                           handleQuestionChange(index, 'options', newOptions);
                        }} className="mt-1">
                          <PlusCircle size={16} className="mr-2"/>Añadir Opción
                        </Button>
                      </div>
                    )}
                  </div>
                ))}
                <Button variant="outline" onClick={addQuestion} className="flex items-center">
                  <PlusCircle size={18} className="mr-2"/>Añadir Pregunta
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="integration" className="space-y-6">
               <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="whatsappNumber" className="font-semibold flex items-center"><Settings size={18} className="mr-2 text-primary" />Número de WhatsApp</Label>
                  <Input id="whatsappNumber" name="whatsappNumber" placeholder="Ej: +34612345678" value={landingPage.whatsappNumber} onChange={handleInputChange}/>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="calendarUrl" className="font-semibold flex items-center"><Settings size={18} className="mr-2 text-primary" />URL del Calendario</Label>
                  <Input id="calendarUrl" name="calendarUrl" placeholder="URL de tu calendario de citas" value={landingPage.calendarUrl} onChange={handleInputChange}/>
                </div>
              </div>
              <div className="pt-4 border-t">
                <Label className="font-semibold text-lg mb-3 block flex items-center"><Mail size={20} className="mr-2 text-primary"/>Mailchimp</Label>
                 <div className="space-y-2">
                  <Label htmlFor="mailchimpFormAction">URL del Formulario de Mailchimp (Action URL)</Label>
                  <Input 
                    id="mailchimpFormAction" 
                    name="mailchimpFormAction"
                    placeholder="Pega la URL 'action' del código de tu formulario Mailchimp" 
                    value={landingPage.mailchimpFormAction || ''}
                    onChange={handleInputChange}
                  />
                   <p className="text-xs text-gray-500">Encuentra esto en el código HTML de tu formulario de Mailchimp.</p>
                </div>
                <div className="space-y-2 mt-4">
                  <Label htmlFor="mailchimpEmailFieldName">Nombre del Campo de Email en Mailchimp</Label>
                  <Input 
                    id="mailchimpEmailFieldName" 
                    name="mailchimpEmailFieldName"
                    placeholder="Normalmente 'EMAIL' o 'MERGE0'" 
                    value={landingPage.mailchimpEmailFieldName || 'EMAIL'}
                    onChange={handleInputChange}
                  />
                   <p className="text-xs text-gray-500">Este es el atributo 'name' del campo de email en tu formulario Mailchimp.</p>
                </div>
              </div>
            </TabsContent>
            <TabsContent value="tracking" className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="facebookPixelId" className="font-semibold flex items-center"><Facebook size={18} className="mr-2 text-primary"/>ID del Pixel de Facebook</Label>
                <Input 
                    id="facebookPixelId" 
                    name="facebookPixelId"
                    placeholder="Ej: 123456789012345" 
                    value={landingPage.facebookPixelId || ''}
                    onChange={handleInputChange}
                />
                <p className="text-xs text-gray-500">Puedes usar el Pixel ID global (configurado en el Dashboard) o uno específico para esta página.</p>
              </div>
            </TabsContent>
          </Tabs>

          <div className="flex justify-end gap-4 mt-12 border-t pt-8">
            <Button variant="outline" onClick={() => navigate('/dashboard')}>
              Cancelar
            </Button>
            <Button onClick={handleSave} size="lg">
              {isEditing ? 'Actualizar' : 'Guardar'} Landing Page
            </Button>
          </div>
        </motion.div>
      </div>
    </div>
  );
}

export default GeneratorPage;
