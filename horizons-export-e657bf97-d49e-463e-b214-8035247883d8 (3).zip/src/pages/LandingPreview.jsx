
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { MessageSquare, CalendarDays, Mail } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { initFacebookPixel } from '@/lib/facebook-pixel';

const defaultHeroImage = 'https://images.unsplash.com/photo-1522071820081-009f0129c7da?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80';

function LandingPreview() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [landingPage, setLandingPage] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [answers, setAnswers] = useState({});
  const [formStep, setFormStep] = useState(0);
  const [emailForMailchimp, setEmailForMailchimp] = useState('');

  useEffect(() => {
    const pages = JSON.parse(localStorage.getItem('landingPages') || '[]');
    const pageData = pages.find(p => p.id === parseInt(id));

    if (pageData) {
      setLandingPage(pageData);
      if (pageData.facebookPixelId && typeof window !== 'undefined' && window.fbq) {
        try {
           initFacebookPixel(pageData.facebookPixelId);
        } catch (error) {
            console.error("Failed to initialize Facebook Pixel:", error);
             toast({
                title: "Error de Pixel",
                description: "No se pudo inicializar el Pixel de Facebook.",
                variant: "destructive",
            });
        }
      } else if (pageData.facebookPixelId && typeof window !== 'undefined' && !window.fbq) {
        setTimeout(() => {
           if (window.fbq) {
                try {
                    initFacebookPixel(pageData.facebookPixelId);
                } catch (error) {
                    console.error("Failed to initialize FB Pixel (delayed):", error);
                }
           }
        }, 1000);
      }
    } else {
      toast({ title: "Error", description: "Landing page no encontrada.", variant: "destructive" });
      navigate('/');
    }
    setIsLoading(false);
  }, [id, navigate, toast]);

  const handleAnswerChange = (questionId, value) => {
    setAnswers(prev => ({ ...prev, [questionId]: value }));
  };

  const handleNextStep = () => {
    const currentQuestionObj = landingPage.questions && landingPage.questions[formStep];
    if (currentQuestionObj) {
      if (answers[currentQuestionObj.id] === undefined && currentQuestionObj.type !== 'text_input') { 
        toast({ title: "Espera", description: "Por favor, responde la pregunta.", variant: "default" });
        return;
      }
      if (typeof window !== 'undefined' && window.fbq && landingPage.facebookPixelId) {
        window.fbq('track', 'Lead', { content_name: landingPage.title, question: currentQuestionObj.question, answer: answers[currentQuestionObj.id] });
      }
    }
    setFormStep(prev => prev + 1);
  };
  
  const handleMailchimpSubmit = async (e) => {
    e.preventDefault();
    if (!emailForMailchimp) {
        toast({ title: "Error", description: "Por favor ingresa tu email.", variant: "destructive"});
        return;
    }
    
    toast({ title: "¡Gracias!", description: `Te has suscrito con ${emailForMailchimp}. (Simulación)`});
    if (typeof window !== 'undefined' && window.fbq && landingPage.facebookPixelId) {
        window.fbq('track', 'CompleteRegistration', { content_name: landingPage.title, email: emailForMailchimp });
    }
    setEmailForMailchimp(''); 
  };


  if (isLoading) {
    return <div className="flex justify-center items-center min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 text-white">Cargando vista previa...</div>;
  }

  if (!landingPage) {
    return <div className="flex justify-center items-center min-h-screen bg-gradient-to-br from-red-500 to-red-700 text-white">Error al cargar la landing page.</div>;
  }
  
  const currentQuestion = landingPage.questions && landingPage.questions[formStep];
  const allQuestionsAnswered = landingPage.questions ? formStep >= landingPage.questions.length : true;

  const pageFont = landingPage.font || 'Poppins';
  const dynamicStyles = `
    :root {
      --lp-primary-color: ${landingPage.primaryColor || '#5E4AE3'};
      --lp-secondary-color: ${landingPage.secondaryColor || '#F970B5'};
    }
    body { font-family: '${pageFont}', sans-serif; }
    .lp-gradient-text { background-image: linear-gradient(to right, var(--lp-primary-color), var(--lp-secondary-color)); -webkit-background-clip: text; background-clip: text; color: transparent; }
    .lp-bg-primary { background-color: var(--lp-primary-color); }
    .lp-text-primary { color: var(--lp-primary-color); }
    .lp-border-primary { border-color: var(--lp-primary-color); }
    .lp-button-primary { background-color: var(--lp-primary-color); color: white; }
    .lp-button-primary:hover { opacity: 0.9; }
  `;

  return (
    <>
      <style>{dynamicStyles}</style>
      <div className="min-h-screen bg-slate-100 text-slate-800">
        <header 
          className="py-12 md:py-20 bg-cover bg-center relative"
          style={{ backgroundImage: landingPage.heroImage ? `url(${landingPage.heroImage})` : `url(${defaultHeroImage})` }}
        >
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm"></div>
          <div className="container mx-auto px-6 text-center relative z-10">
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="text-4xl md:text-6xl font-bold text-white mb-6"
            >
              {landingPage.title}
            </motion.h1>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="text-lg md:text-xl text-slate-200 mb-10 max-w-2xl mx-auto"
            >
              {landingPage.description}
            </motion.p>
          </div>
        </header>

        <main className="container mx-auto px-6 py-12 md:py-16">
          {landingPage.sections?.filter(s => s.type === 'hero' && s.id !== landingPage.sections[0]?.id).map((section, idx) => (
            <motion.section 
                key={section.id || `extra-hero-${idx}`}
                initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 * idx}}
                className="mb-12 p-8 bg-white rounded-lg shadow-lg"
            >
                <h2 className="text-3xl font-semibold lp-gradient-text mb-4">{section.title}</h2>
                <p className="text-slate-600">{section.content}</p>
            </motion.section>
          ))}

          <motion.section 
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
            className="max-w-2xl mx-auto bg-white p-8 md:p-12 rounded-xl shadow-2xl"
          >
            {!allQuestionsAnswered && currentQuestion ? (
              <div className="space-y-8">
                <h2 className="text-2xl md:text-3xl font-semibold lp-gradient-text mb-6 text-center">
                  {currentQuestion.question}
                </h2>
                {currentQuestion.type === 'yes_no' && (
                  <div className="flex justify-center gap-6">
                    <Button 
                      onClick={() => { handleAnswerChange(currentQuestion.id, 'yes'); handleNextStep(); }}
                      className="lp-button-primary px-8 py-3 text-lg"
                    >
                      Sí
                    </Button>
                    <Button 
                      onClick={() => { handleAnswerChange(currentQuestion.id, 'no'); handleNextStep(); }}
                      variant="outline" 
                      className="px-8 py-3 text-lg lp-border-primary lp-text-primary hover:bg-primary/10"
                    >
                      No
                    </Button>
                  </div>
                )}
                {currentQuestion.type === 'text_input' && (
                  <div className="space-y-4">
                    <Input 
                      type="text"
                      placeholder="Escribe tu respuesta aquí..."
                      value={answers[currentQuestion.id] || ''}
                      onChange={(e) => handleAnswerChange(currentQuestion.id, e.target.value)}
                      className="w-full"
                    />
                     <Button 
                      onClick={handleNextStep}
                      className="lp-button-primary px-8 py-3 text-lg w-full"
                    >
                      Siguiente
                    </Button>
                  </div>
                )}
                 {currentQuestion.type === 'multiple_choice' && currentQuestion.options && (
                  <div className="space-y-3">
                    {currentQuestion.options.map((option, optionIndex) => (
                       <Button 
                        key={optionIndex}
                        onClick={() => { handleAnswerChange(currentQuestion.id, option); handleNextStep(); }}
                        variant={answers[currentQuestion.id] === option ? "default" : "outline"}
                        className={`w-full justify-start text-left py-3 px-4 ${answers[currentQuestion.id] === option ? 'lp-button-primary' : 'lp-border-primary lp-text-primary hover:bg-primary/10'}`}
                      >
                        {option}
                      </Button>
                    ))}
                  </div>
                )}
                <div className="text-center text-sm text-slate-500">
                  Paso {formStep + 1} de {landingPage.questions.length}
                </div>
              </div>
            ) : (
              <div className="text-center space-y-8">
                <h2 className="text-2xl md:text-3xl font-semibold lp-gradient-text">¡Gracias por tus respuestas!</h2>
                <p className="text-slate-600">Ahora puedes ponerte en contacto con nosotros o agendar una llamada.</p>
                <div className="flex flex-col md:flex-row justify-center gap-4 md:gap-6">
                  {landingPage.whatsappNumber && (
                    <Button 
                      asChild 
                      className="lp-button-primary px-8 py-3 text-lg w-full md:w-auto"
                      onClick={() => { if (typeof window !== 'undefined' && window.fbq && landingPage.facebookPixelId) window.fbq('track', 'Contact', {contact_method: 'whatsapp'}); }}
                    >
                      <a href={`https://wa.me/${landingPage.whatsappNumber.replace(/\D/g, '')}?text=Hola!%20Vengo%20de%20la%20landing%20page%20'${encodeURIComponent(landingPage.title)}'%20y%20estoy%20interesado.`} target="_blank" rel="noopener noreferrer" className="flex items-center">
                        <MessageSquare className="mr-2 h-5 w-5" /> Escribir por WhatsApp
                      </a>
                    </Button>
                  )}
                  {landingPage.calendarUrl && (
                    <Button 
                      asChild 
                      variant="outline" 
                      className="px-8 py-3 text-lg w-full md:w-auto lp-border-primary lp-text-primary hover:bg-primary/10"
                      onClick={() => { if (typeof window !== 'undefined' && window.fbq && landingPage.facebookPixelId) window.fbq('track', 'Schedule'); }}
                    >
                      <a href={landingPage.calendarUrl} target="_blank" rel="noopener noreferrer" className="flex items-center">
                        <CalendarDays className="mr-2 h-5 w-5" /> Agendar Videollamada
                      </a>
                    </Button>
                  )}
                </div>
                {landingPage.mailchimpFormAction && (
                  <div className="pt-8 border-t mt-8">
                    <h3 className="text-xl font-medium text-slate-700 mb-4">O suscríbete a nuestra lista de correo:</h3>
                    <form onSubmit={handleMailchimpSubmit} className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto" action={landingPage.mailchimpFormAction} method="POST" target="_blank">
                       <Input 
                        type="email" 
                        name={landingPage.mailchimpEmailFieldName || "EMAIL"}
                        placeholder="Tu correo electrónico" 
                        value={emailForMailchimp}
                        onChange={(e) => setEmailForMailchimp(e.target.value)}
                        className="flex-grow"
                        required 
                      />
                      <Button type="submit" className="lp-button-primary flex items-center justify-center">
                        <Mail className="mr-2 h-5 w-5" /> Suscribirme
                      </Button>
                    </form>
                     <p className="text-xs text-slate-500 mt-2">Al suscribirte, aceptas recibir comunicaciones por correo electrónico.</p>
                  </div>
                )}
              </div>
            )}
          </motion.section>

          {landingPage.sections?.filter(s => s.type !== 'hero').map((section, idx) => (
            <motion.section 
                key={section.id || `section-${idx}`}
                initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 * (idx + 1)}}
                className="mt-12 p-8 bg-white rounded-lg shadow-lg"
            >
                <h2 className="text-3xl font-semibold lp-gradient-text mb-4">{section.title}</h2>
                {section.type === 'faq' && section.items?.length > 0 ? (
                    <div className="space-y-4">
                        {section.items.map((item, itemIdx) => (
                            <details key={item.id || `faq-${itemIdx}`} className="p-3 bg-slate-50 rounded">
                                <summary className="font-medium cursor-pointer">{item.q}</summary>
                                <p className="pt-2 text-slate-600">{item.a}</p>
                            </details>
                        ))}
                    </div>
                ) : section.type === 'features' && section.items?.length > 0 ? (
                     <div className="grid md:grid-cols-2 gap-6">
                        {section.items.map((item, itemIdx) => (
                            <div key={item.id || `feat-${itemIdx}`} className="p-4 border rounded-md">
                                <h4 className="font-semibold text-lg lp-text-primary">{item.name}</h4>
                                <p className="text-slate-600 text-sm">{item.desc}</p>
                            </div>
                        ))}
                    </div>
                ) : (
                    <p className="text-slate-600">{section.content}</p>
                )}
            </motion.section>
          ))}

        </main>

        <footer className="text-center py-8 bg-slate-200">
          <p className="text-sm text-slate-600">&copy; {new Date().getFullYear()} {landingPage.title}. Todos los derechos reservados.</p>
           <Button variant="link" onClick={() => navigate('/dashboard')} className="mt-2 lp-text-primary">Volver al Dashboard</Button>
        </footer>
      </div>
    </>
  );
}

export default LandingPreview;
