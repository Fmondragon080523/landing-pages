
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Pencil, Trash2, Eye } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

function LandingPagesTab({ landingPages, onUpdatePages, navigate }) {
  const [searchTerm, setSearchTerm] = useState('');
  const { toast } = useToast();

  const filteredPages = landingPages.filter(page => 
    page.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const deletePage = (id) => {
    const newPages = landingPages.filter(page => page.id !== id);
    onUpdatePages(newPages);
    toast({ title: "Landing Page Eliminada", description: "La landing page ha sido eliminada." });
  };

  return (
    <div>
      <div className="mb-6">
        <Input
          placeholder="Buscar landing pages..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="max-w-md"
        />
      </div>

      <div className="grid gap-6">
        {filteredPages.map((page, index) => (
          <motion.div
            key={page.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-white rounded-lg shadow-sm p-6 flex items-center justify-between"
          >
            <div>
              <h2 className="text-xl font-semibold mb-2">{page.title}</h2>
              <p className="text-gray-600">{page.description}</p>
            </div>
            <div className="flex gap-3">
              <Button
                variant="outline"
                size="icon"
                onClick={() => navigate(`/preview/${page.id}`)}
                title="Ver"
              >
                <Eye className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                size="icon"
                onClick={() => navigate(`/generator/${page.id}`)}
                title="Editar"
              >
                <Pencil className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                size="icon"
                onClick={() => deletePage(page.id)}
                title="Eliminar"
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </motion.div>
        ))}

        {filteredPages.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-600">No se encontraron landing pages</p>
          </div>
        )}
      </div>
    </div>
  );
}

export default LandingPagesTab;
