
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { UserX, UserCheck } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/AuthContext';

function UserManagementTab({ allUsers, onUpdateUsers, currentUserEmail }) {
  const [userSearchTerm, setUserSearchTerm] = useState('');
  const { toast } = useToast();
  const { toggleUserStatus } = useAuth();

  const filteredUsers = allUsers.filter(u =>
    u.email.toLowerCase().includes(userSearchTerm.toLowerCase())
  );

  const handleToggleUserStatus = (userId) => {
    if (toggleUserStatus(userId)) {
      const updatedUsers = JSON.parse(localStorage.getItem('users') || '[]');
      onUpdateUsers(updatedUsers);
    }
  };

  return (
    <div>
      <div className="mb-6">
        <Input
          placeholder="Buscar usuarios por email..."
          value={userSearchTerm}
          onChange={(e) => setUserSearchTerm(e.target.value)}
          className="max-w-md"
        />
      </div>
      <div className="bg-white rounded-lg shadow-sm overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Rol</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Estado</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Acciones</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {filteredUsers.map((u) => (
              <tr key={u.id}>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{u.email}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{u.isAdmin ? 'Admin' : 'Usuario'}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm">
                  <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${u.isEnabled ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                    {u.isEnabled ? 'Habilitado' : 'Deshabilitado'}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                  {u.email !== currentUserEmail && ( 
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleToggleUserStatus(u.id)}
                      title={u.isEnabled ? 'Deshabilitar Usuario' : 'Habilitar Usuario'}
                    >
                      {u.isEnabled ? <UserX className="h-4 w-4 mr-2" /> : <UserCheck className="h-4 w-4 mr-2" />}
                      {u.isEnabled ? 'Deshabilitar' : 'Habilitar'}
                    </Button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {filteredUsers.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-600">No se encontraron usuarios</p>
          </div>
        )}
      </div>
    </div>
  );
}

export default UserManagementTab;
