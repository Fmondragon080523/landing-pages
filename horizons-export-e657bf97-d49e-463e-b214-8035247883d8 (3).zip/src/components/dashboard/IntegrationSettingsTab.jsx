
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';

function IntegrationSettingsTab({ settings, onUpdateSettings, isAdmin }) {
  const { toast } = useToast();
  const [currentSettings, setCurrentSettings] = useState(settings);

  useEffect(() => {
    setCurrentSettings(settings);
  }, [settings]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setCurrentSettings(prev => ({ ...prev, [name]: value }));
  };

  const handleSave = () => {
    onUpdateSettings(currentSettings);
    toast({ title: "Configuración Guardada", description: "Los ajustes de integración han sido guardados." });
  };

  return (
    <div className="bg-white p-6 rounded-xl shadow-sm space-y-8 max-w-2xl mx-auto">
      <div>
        <h3 className="text-xl font-semibold mb-4 text-primary">Facebook Pixel</h3>
        <div className="space-y-2">
          <Label htmlFor="facebookPixelId">ID del Pixel de Facebook {isAdmin && "(Global por defecto)"}</Label>
          <Input 
            id="facebookPixelId" 
            name="facebookPixelId"
            placeholder="Ej: 123456789012345" 
            value={currentSettings.facebookPixelId || ''}
            onChange={handleChange}
          />
          <p className="text-xs text-gray-500">
            Ingresa el ID de tu Pixel de Facebook. {isAdmin ? "Este será el ID por defecto para nuevas landing pages." : "Este ID se usará para tus landing pages si no especificas uno diferente al crearla."}
          </p>
        </div>
      </div>

      <div>
        <h3 className="text-xl font-semibold mb-4 text-primary">Mailchimp</h3>
        <div className="space-y-4">
          {isAdmin && (
            <div className="space-y-2">
              <Label htmlFor="mailchimpApiKey">API Key de Mailchimp (Global por defecto - Solo Admin)</Label>
              <Input 
                id="mailchimpApiKey" 
                name="mailchimpApiKey"
                type="password"
                placeholder="Ej: abc123xyz789-us18" 
                value={currentSettings.mailchimpApiKey || ''}
                onChange={handleChange}
                disabled={!isAdmin}
              />
              <p className="text-xs text-gray-500">Ingresa tu API Key global. En una app real, esto se manejaría de forma más segura. Solo visible para administradores.</p>
            </div>
          )}
          <div className="space-y-2">
            <Label htmlFor="mailchimpAudienceId">ID de Audiencia de Mailchimp {isAdmin && "(Global por defecto)"}</Label>
            <Input 
              id="mailchimpAudienceId" 
              name="mailchimpAudienceId"
              placeholder="Ej: a1b2c3d4e5" 
              value={currentSettings.mailchimpAudienceId || ''}
              onChange={handleChange}
            />
            <p className="text-xs text-gray-500">
              Ingresa el ID de la audiencia. {isAdmin ? "Este será el ID de audiencia por defecto." : "Este ID se usará para tus landing pages."}
            </p>
          </div>
           <p className="text-sm text-gray-600 p-3 bg-blue-50 border border-blue-200 rounded-md">
            <strong>Nota:</strong> Para una integración más directa con Mailchimp (y más segura que usar API Keys en el frontend), considera usar la "URL del Formulario de Mailchimp (Action URL)" directamente en el generador de cada landing page. Puedes encontrar esta URL en el código HTML que Mailchimp te proporciona para incrustar formularios.
          </p>
        </div>
      </div>
      
      <div className="flex justify-end">
        <Button onClick={handleSave}>Guardar Configuración</Button>
      </div>
    </div>
  );
}

export default IntegrationSettingsTab;
