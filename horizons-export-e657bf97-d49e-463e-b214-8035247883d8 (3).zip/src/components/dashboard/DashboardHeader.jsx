
import React from 'react';
import { Button } from '@/components/ui/button';

function DashboardHeader({ user, isAdmin, onCreatePage }) {
  return (
    <div className="flex justify-between items-center mb-8">
      <div>
        <h1 className="text-3xl font-bold">Dashboard</h1>
        <p className="text-gray-600">Bienvenido, {user?.email} {isAdmin && '(Admin)'}</p>
      </div>
      <Button onClick={onCreatePage}>
        Crear Nueva Landing Page
      </Button>
    </div>
  );
}

export default DashboardHeader;
