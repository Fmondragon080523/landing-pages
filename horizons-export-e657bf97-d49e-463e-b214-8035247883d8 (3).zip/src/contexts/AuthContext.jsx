
import React, { createContext, useContext, useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/components/ui/use-toast';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();

  const ADMIN_EMAIL = "osv25monhdz@gmail.com";
  const ADMIN_PASSWORD = "Sasukedemonio01";

  useEffect(() => {
    let users = JSON.parse(localStorage.getItem('users') || '[]');
    const adminUserExists = users.some(u => u.email === ADMIN_EMAIL);

    if (!adminUserExists) {
      users.push({ id: Date.now(), email: ADMIN_EMAIL, password: ADMIN_PASSWORD, isAdmin: true, isEnabled: true });
      localStorage.setItem('users', JSON.stringify(users));
    } else {
      users = users.map(u => u.email === ADMIN_EMAIL ? { ...u, password: ADMIN_PASSWORD, isAdmin: true, isEnabled: true } : u);
      localStorage.setItem('users', JSON.stringify(users));
    }
    
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      const parsedUser = JSON.parse(storedUser);
      const fullUser = users.find(u => u.id === parsedUser.id);
      if (fullUser && fullUser.isEnabled) {
        setUser(fullUser);
        setIsAuthenticated(true);
        if (fullUser.email === ADMIN_EMAIL) {
          setIsAdmin(true);
        }
      } else if (fullUser && !fullUser.isEnabled) {
        localStorage.removeItem('user');
         toast({
          title: "Cuenta deshabilitada",
          description: "Tu cuenta ha sido deshabilitada por un administrador.",
          variant: "destructive",
        });
      }
    }
  }, []);

  const login = (email, password) => {
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const foundUser = users.find(u => u.email === email && u.password === password);
    
    if (foundUser) {
      if (!foundUser.isEnabled) {
        toast({
          title: "Cuenta deshabilitada",
          description: "Esta cuenta ha sido deshabilitada. Contacta al administrador.",
          variant: "destructive"
        });
        return false;
      }
      setUser(foundUser);
      setIsAuthenticated(true);
      if (foundUser.email === ADMIN_EMAIL) {
        setIsAdmin(true);
      }
      localStorage.setItem('user', JSON.stringify(foundUser));
      toast({
        title: "¡Bienvenido!",
        description: "Has iniciado sesión correctamente.",
      });
      navigate('/dashboard');
      return true;
    }
    
    toast({
      title: "Error",
      description: "Credenciales incorrectas",
      variant: "destructive"
    });
    return false;
  };

  const register = (email, password) => {
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    
    if (users.some(u => u.email === email)) {
      toast({
        title: "Error",
        description: "El email ya está registrado",
        variant: "destructive"
      });
      return false;
    }

    const newUser = { id: Date.now(), email, password, isAdmin: false, isEnabled: true };
    users.push(newUser);
    localStorage.setItem('users', JSON.stringify(users));
    
    setUser(newUser);
    setIsAuthenticated(true);
    localStorage.setItem('user', JSON.stringify(newUser));
    
    toast({
      title: "¡Registro exitoso!",
      description: "Tu cuenta ha sido creada correctamente.",
    });
    navigate('/dashboard');
    return true;
  };

  const logout = () => {
    setUser(null);
    setIsAuthenticated(false);
    setIsAdmin(false);
    localStorage.removeItem('user');
    navigate('/login');
    toast({
      title: "Sesión cerrada",
      description: "Has cerrado sesión correctamente.",
    });
  };

  const getAllUsers = () => {
    if (!isAdmin) return [];
    return JSON.parse(localStorage.getItem('users') || '[]');
  };

  const toggleUserStatus = (userId) => {
    if (!isAdmin) return false;
    let users = JSON.parse(localStorage.getItem('users') || '[]');
    const userIndex = users.findIndex(u => u.id === userId);

    if (userIndex > -1 && users[userIndex].email !== ADMIN_EMAIL) {
      users[userIndex].isEnabled = !users[userIndex].isEnabled;
      localStorage.setItem('users', JSON.stringify(users));
      toast({
        title: "Usuario actualizado",
        description: `El usuario ha sido ${users[userIndex].isEnabled ? 'habilitado' : 'deshabilitado'}.`,
      });
      return true;
    }
    toast({
      title: "Error",
      description: "No se pudo actualizar el usuario o intentas deshabilitar al administrador.",
      variant: "destructive"
    });
    return false;
  };


  return (
    <AuthContext.Provider value={{ user, isAuthenticated, isAdmin, login, register, logout, getAllUsers, toggleUserStatus }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth debe ser usado dentro de un AuthProvider');
  }
  return context;
}
