
import { useState, useEffect, useCallback } from 'react';

export function useIntegrationSettings(user, isAdmin) {
  const getInitialSettings = useCallback(() => {
    const globalSettings = JSON.parse(localStorage.getItem('globalIntegrationSettings') || '{}');
    const userSettingsKey = user ? `userIntegrationSettings_${user.id}` : null;
    const userSettings = userSettingsKey ? JSON.parse(localStorage.getItem(userSettingsKey) || '{}') : {};
    
    return {
      facebookPixelId: userSettings.facebookPixelId || (isAdmin ? globalSettings.facebookPixelId : ''),
      mailchimpApiKey: userSettings.mailchimpApiKey || (isAdmin ? globalSettings.mailchimpApiKey : ''),
      mailchimpAudienceId: userSettings.mailchimpAudienceId || (isAdmin ? globalSettings.mailchimpAudienceId : ''),
    };
  }, [user, isAdmin]);

  const [integrationSettings, setIntegrationSettings] = useState(getInitialSettings);

  useEffect(() => {
    if (user) {
      setIntegrationSettings(getInitialSettings());
    }
  }, [user, getInitialSettings]);

  const updateIntegrationSettings = useCallback((newSettings) => {
    setIntegrationSettings(newSettings);
    if (isAdmin) {
      localStorage.setItem('globalIntegrationSettings', JSON.stringify(newSettings));
    }
    if (user) {
      const userSettingsKey = `userIntegrationSettings_${user.id}`;
      localStorage.setItem(userSettingsKey, JSON.stringify(newSettings));
    }
  }, [isAdmin, user]);

  return { integrationSettings, updateIntegrationSettings, reloadIntegrationSettings: getInitialSettings };
}
