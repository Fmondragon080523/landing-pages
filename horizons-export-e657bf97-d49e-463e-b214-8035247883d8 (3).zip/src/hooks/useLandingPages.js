
import { useState, useEffect, useCallback } from 'react';

export function useLandingPages(user, isAdmin) {
  const [landingPages, setLandingPages] = useState([]);

  const loadLandingPages = useCallback(() => {
    const storedPages = JSON.parse(localStorage.getItem('landingPages') || '[]');
    const userPages = isAdmin ? storedPages : storedPages.filter(p => p.userId === user?.id);
    setLandingPages(userPages);
  }, [isAdmin, user]);

  useEffect(() => {
    if (user) {
      loadLandingPages();
    }
  }, [user, loadLandingPages]);

  const updateLandingPages = useCallback((updatedPages) => {
    let allStoredPages = JSON.parse(localStorage.getItem('landingPages') || '[]');
    if (isAdmin) {
      allStoredPages = updatedPages;
    } else if (user) {
      const nonUserPages = allStoredPages.filter(p => p.userId !== user.id);
      allStoredPages = [...nonUserPages, ...updatedPages];
    }
    
    const pagesToSet = isAdmin ? allStoredPages : updatedPages.filter(p => p.userId === user?.id);
    setLandingPages(pagesToSet);
    localStorage.setItem('landingPages', JSON.stringify(allStoredPages));
  }, [isAdmin, user]);

  return { landingPages, updateLandingPages, loadLandingPages };
}
