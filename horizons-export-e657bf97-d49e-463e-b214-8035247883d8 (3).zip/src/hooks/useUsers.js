
import { useState, useEffect, useCallback } from 'react';

export function useUsers(isAdmin) {
  const [allUsers, setAllUsers] = useState([]);

  const loadUsers = useCallback(() => {
    if (isAdmin) {
      const storedUsers = JSON.parse(localStorage.getItem('users') || '[]');
      setAllUsers(storedUsers);
    }
  }, [isAdmin]);

  useEffect(() => {
    loadUsers();
  }, [loadUsers]);

  const updateAllUsers = useCallback((updatedUsers) => {
    if (!isAdmin) return;
    setAllUsers(updatedUsers);
    localStorage.setItem('users', JSON.stringify(updatedUsers));
  }, [isAdmin]);

  return { allUsers, updateAllUsers, loadUsers };
}
